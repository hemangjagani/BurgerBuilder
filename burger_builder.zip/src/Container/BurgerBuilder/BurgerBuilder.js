import React, { Component } from 'react'
import Aux from '../../Hoc/Auxilary/Auxilary'
import Burger from '../../Components/Burger/Burger'
import BurgerControlers from '../../Components/BurgerControlers/BurgerControlers';
import Modal from '../../Components/UI/Modal/Modal';
import OrderSummery from '../../Components/Burger/OrderSummery/OrderSummery';
// import axios from '../../axios-order'
import axios from 'axios';  
import Spinner from '../../Components/UI/Spinner/Spinner';
import withErrorHandler from '../../Hoc/withErrorHandler/withErrorHandler';
import { connect } from 'react-redux';
// import * as actionTypes from '../../Store/action/actionsTypes'
import * as action from '../../Store/action/indexAction'

export class BurgerBuilder extends Component {
    constructor(props) {
        super(props);
        this.state = {
            purchasable: false,
            showModal: false,
            showLoading: false,
        }
    }
    componentDidMount() {
        this.props.onSetIngredient();
    }
    updatePurchaseState(ingredients) {

        const sum = Object.keys(ingredients)
            .map(igKey => {
                return ingredients[igKey];
            })
            .reduce((sum, el) => {
                return sum + el;
            }, 0);
        return sum > 0 ;
    }

    orderToModelHandler = () => {
        if(this.props.isAuthenticated)
        {
            this.setState({ showModal: true })
        }
        else{
            this.props.onSetAuthRedirectPath('/checkout')
           this.props.history.push('/auth')
        }
    }
    modelToOrderHandler = () => {
        this.setState({ showModal: false })
    }

    OrderConfirmHandler = () => {
        // this.setState({ showLoading: true, showModal: true })
        
        const queryParams =[];
        for(let i in this.state.ingredient)
        {
           queryParams.push(encodeURIComponent(i)+'='+ encodeURIComponent(this.state.ingredient[i]))
        }
        queryParams.push('price='+ this.state.totalPrice)
        const queryString = queryParams.join('&');
          this.props.history.push({
          pathname:'/checkout',
          search : '?' + queryString
          
        })
        this.props.onInitPuchased()
    }
    OrderCancledHandler = () => {
        this.setState({ showModal: false })
    }


    render() {
        const disableInfo = {
            ...this.props.ing
        }
        for (let key in disableInfo) {
            disableInfo[key] = disableInfo[key] <= 0
        }
        let orderSummery =null;
        let burger = this.props.error? <p>Something went wrong!!!</p> :<Spinner/>;
        
        if (this.props.ing) {
            burger = (<Aux>
                <Burger ingredient={this.props.ing} />
                <BurgerControlers
                    ingredientAdded={this.props.onIngredientAdded}
                    ingredientRemoved={this.props.onIngredientRemoved}
                    disabled={disableInfo}
                    price={this.props.price}
                    INGREDIENT_PRICE={this.props.INGREDIENT_PRICE}
                    purchasable={this.updatePurchaseState(this.props.ing)}
                    orderNowClicked={this.orderToModelHandler}
                    isAuth={this.props.isAuthenticated}
                />
             </Aux>
            )
            orderSummery=  <OrderSummery totalPrice={this.props.price}
                  ingredient={this.props.ing}
                  OrderConfirmHandler={this.OrderConfirmHandler}
                  OrderCancledHandler={this.OrderCancledHandler} />
                 
        }
        if (this.state.showLoading) {
            orderSummery = <Spinner />
        }
        

        return (
            <Aux>
                <Modal showModal={this.state.showModal} modelToOrderHandler={this.modelToOrderHandler}>
                    {orderSummery}
                </Modal>
                {burger}

            </Aux>
        )
    }
}

const mapStateToProps =(state)=>{
    return{
        ing:state.burgerBuilder.ingredient,
        price:state.burgerBuilder.totalPrice,
        INGREDIENT_PRICE:state.burgerBuilder.INGREDIENT_PRICE,
        error:state.burgerBuilder.error,
        isAuthenticated: state.auth.token!=null
    }
}
const mapDispatchToProps = (dispatch)=>{
    return{
        onIngredientAdded: (igName)=> dispatch(action.addIngredient(igName)),
        onIngredientRemoved: (igName) => dispatch(action.removeIngredient(igName)),
        onSetIngredient: ()=> dispatch( action.initIngredient()),
        onInitPuchased: ()=> dispatch(action.PURCHASED_ORDER()),
        onSetAuthRedirectPath : (path)=>dispatch(action.auth_set_redirect_path(path))
    }
}
export default connect(mapStateToProps,mapDispatchToProps)(withErrorHandler(BurgerBuilder,axios));
