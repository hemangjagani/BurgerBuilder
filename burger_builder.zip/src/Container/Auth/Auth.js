import React, { Component } from 'react'
import Input from '../../Components/UI/Input/Input';
import Button from '../../Components/UI/Button/Button';
import classes from '../Order/ContactData/ContactData.module.css'
import * as action from '../../Store/action/indexAction';
import {connect} from 'react-redux'
import Spinner from '../../Components/UI/Spinner/Spinner';
import { Redirect } from 'react-router-dom';
import {updateObject,checkValidity} from '../../shared/utility'

class Auth extends Component {
    state = {
        controls:
        {
            email: {
                inputtype: 'input',
                elementConfig: {
                    type: 'email',
                    placeholder: 'Your E-mail Address'
                },
                value: '',
                validation:
                {
                    required: true,
                    isEmail: true,
                },
                valid: false,
                touched: false,
                errorMessage: '',
            },
            password: {
                inputtype: 'input',
                elementConfig: {
                    type: 'password',
                    placeholder: 'Your Password'
                },
                value: '',
                validation:
                {
                    required: true,
                    minLength: 4
                },
                valid: false,
                touched: false,
                errorMessage: '',
            },
        },
        isSignUp:true
    }
    componentDidMount()
    {
    if(!this.props.buildingBurger && this.props.authRedirectPath !== '/')
    {
        this.props.onSetAuthRedirectPath()
    }
    }
   
    inputChangedHandler = (event, controlName) => {

        const updateControls = updateObject(this.state.controls,{
            [controlName]:updateObject(this.state.controls[controlName],
                {value:event.target.value,
                    valid: checkValidity(event.target.value, this.state.controls[controlName].validation),
                    touched:true
                })
        })

        let formIsValid = true;
        for(let key in updateControls)
        {
            formIsValid = updateControls[key].valid && formIsValid
        }
        this.setState({
            controls: updateControls,formIsValid:formIsValid
        })
        this.setState({ controls: updateControls })

        
    }
      submitHandler =(event)=>
      {
      event.preventDefault();
      this.props.onAuthInit(this.state.controls.email.value,this.state.controls.password.value,this.state.isSignUp)
    }
    
    authChangeHandler = ()=>{
        this.setState(prevState=>{
            return {isSignUp:!prevState.isSignUp}
        })
    }
    render() {
        
        const formElementArray = [];
        for (let key in this.state.controls) {
            formElementArray.push(
                { id: key, config: this.state.controls[key] }
            )
        }

        let form = formElementArray.map(element => {
            return (
                <Input key={element.id}
                    inputtypes={element.config.inputtype}
                    elementconfig={element.config.elementConfig}
                    value={element.config.value}
                    invalid={!element.config.valid}
                    shouldvalidate={element.config.validation}
                    touched={element.config.touched}
                    valuetype={element.id}
                    // formIsValid={!this.state.formIsValid}
                    errormessage={element.config.errorMessage}
                    changed={(event) => this.inputChangedHandler(event, element.id)}
                />
            )
        })
        if(this.props.ShowLoading)
        {
            form = <Spinner/>
        }
        if(this.props.error)
        {
            var errorMessage = <p>{this.props.error.message}</p>
        }
        let authRedirect = null;
        if(this.props.isAutheticated)
        {
            authRedirect = <Redirect to={this.props.authRedirectPath}/>
        }
        return (
            <div className={classes.ContactData}>
                {authRedirect}
                {errorMessage}
                <form onSubmit={this.submitHandler}>
                    {form}
                    <Button btnType="Success" disabled={!this.state.formIsValid}>Submit</Button>
                </form>
                    <Button btnType="Danger" clicked={this.authChangeHandler}> SWITCH TO {this.state.isSignUp? "SIGNIN" : "SIGNUP"} </Button>
            </div>
        )

    }
}

const mapStateToProps = state=>{
    return{
        ShowLoading: state.auth.ShowLoading,
        error:state.auth.error,
        isAutheticated: state.auth.token!=null,
        buildingBurger: state.burgerBuilder.building,
        authRedirectPath: state.auth.authRedirectPath,
    }
} 

const mapDispatchToProps =(dispatch)=>{
    return{
   onAuthInit:(email,password,isSignUp)=>dispatch(action.AUTH_SEND(email,password,isSignUp)),
   onSetAuthRedirectPath:()=>dispatch(action.auth_set_redirect_path('/'))
    }
}

export default connect(mapStateToProps,mapDispatchToProps)(Auth);