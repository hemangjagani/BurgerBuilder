import React, { Component } from 'react'
import CheackoutSummery from '../../Components/Order/CheackoutSummery/CheackoutSummery'
import {Route,Redirect} from 'react-router-dom'
import { connect } from 'react-redux'
import ContactData from './ContactData/ContactData'

class Order extends Component {   
    orderCancledHandler = () => {
        this.props.history.goBack();
    }
    orderConfirmedHandler = () => {
        this.props.history.replace('/checkout/contact-data');
    }
    render() {
        let summery = <Redirect to="/" />
        if(this.props.ing){
            const purchasedRedirect = this.props.purchased?<Redirect to='/'/>:null;
            summery=(
                <div>
                    {purchasedRedirect}
                <CheackoutSummery ingredients={this.props.ing}
                    cancelOrderHandler={this.orderCancledHandler}
                    confirmOrderHandler={this.orderConfirmedHandler} />
                <Route path={this.props.match.path + '/contact-data'} component={ContactData}/>
            </div>
            )
        }
        return summery;
    }
}

const mapStateToProps =(state)=>{
    return{
        ing:state.burgerBuilder.ingredient,
        purchased:state.order.purchased
    }
} 

export default connect(mapStateToProps)(Order)
