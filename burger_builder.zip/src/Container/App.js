import React,{ Component  } from 'react';
import './App.module.css';
import Layout from '../Hoc/Layout/Layout';
import BurgerBuilder from './BurgerBuilder/BurgerBuilder';
import {Route,Switch,withRouter,Redirect} from 'react-router-dom'
import Auth from '../Container/Auth/Auth'
import { connect } from 'react-redux';
import * as actions from '../Store/action/indexAction'
import asyncComponent from '../Hoc/asyncComponent/asycComponent';

const asyncCheckout = asyncComponent(()=>{
  return import('./Order/Order')
})

const asyncMainOrder = asyncComponent(()=>{
  return import('./MainOrder/MainOrder')
})
const asyncLogout = asyncComponent(()=>{
  return import('./Auth/Logout/Logout')
})
const asyncAuth = asyncComponent(()=>{
  return import('../Container/Auth/Auth')
})
class App extends Component {
 
  componentDidMount(){
    this.props.onTryAutoSignup()
  }

  render(){
    let routes = (
      <Switch>
        <Route path ='/auth' component={Auth}/>
        <Route path = '/' component={BurgerBuilder}/>
        <Redirect to="/" />
      </Switch>
    )
    if(this.props.isAuthenticated)
    {
      routes = (
        <Switch>        
          <Route path ='/checkout' component={asyncCheckout}/>
          <Route path='/orders' component={asyncMainOrder}/>
          <Route path='/logout' component={asyncLogout}/>
          <Route path ='/auth' component={asyncAuth}/>
          <Route path='/' component={BurgerBuilder}/>
          <Redirect to="/" />
        </Switch>
      )
    }
    
  return (
    <div>
      <Layout>   
        {routes}
      </Layout>
    </div>
  );
  }
}

const mapStateToProps = state =>{
  return{
    isAuthenticated: state.auth.token !== null
  }
}
const mapDispatchToProps =(dispatch)=>{
  return{
    onTryAutoSignup:()=>dispatch(actions.authCheckState())
  }
}
export default withRouter(connect(mapStateToProps,mapDispatchToProps)(App));

