import React, { Component } from 'react'
import classes from './Modal.module.css'
import BackDrop from '../BackDrop/BackDrop'
import Aux from '../../../Hoc/Auxilary/Auxilary'
import PropTypes from 'prop-types'

class Modal extends Component 
{
shouldComponentUpdate(nextProps,nextState){
   return nextProps.sshowModal!== this.props.showModal || nextProps.children!==this.props.children;
}

    render() {
        return (
            <Aux>
                <BackDrop show={this.props.showModal} clicked={this.props.modelToOrderHandler} />
                <div className={classes.Modal}
                    style={{
                        transform: this.props.showModal ? 'translateY(0)' : 'translateY(-100vh)',
                        opacity: this.props.showModal ? '1' : '0'
                    }}>
                    {this.props.children}
                </div>
            </Aux>
        )
    }
}
Modal.propTypes =
{
    showModal: PropTypes.bool
}
export default Modal
