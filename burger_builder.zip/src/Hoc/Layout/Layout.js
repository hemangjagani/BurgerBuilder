import React, { Component, createContext,} from 'react'
import Aux from '../Auxilary/Auxilary';
import classes from './Layout.module.css'
import ToolBar from '../../Components/Burger/Navigation/ToolBar/ToolBar';
import SideDrawer from '../../Components/Burger/Navigation/SideDrawer/SideDrawer';
import { connect } from 'react-redux';

const isAuthor = createContext ()
class Layout extends Component {

    state = {
        showSideDrawer: false
    }


    showSideDrawerHandler = () => {
        this.setState({ showSideDrawer: false })
    }

    toogleDrawerClickedHandler = () => {
        this.setState((prevState) => {
            return{showSideDrawer: !prevState.showSideDrawer };
        });
}

render()
{
    return (
        <Aux>
            <isAuthor.Provider value={this.props.isAuthenicated}>
            <ToolBar  toogleDrawerClicked={this.toogleDrawerClickedHandler} />
            <SideDrawer open={this.state.showSideDrawer} closed={this.showSideDrawerHandler} />
            </isAuthor.Provider>
            <main className={classes.Content}>
                {this.props.children}
            </main>
        </Aux>
    );
}

};

const mapStateToProps =(state)=>{
return{
    isAuthenicated: state.auth.token!=null
}
}

export default connect(mapStateToProps)(Layout);
export {isAuthor}